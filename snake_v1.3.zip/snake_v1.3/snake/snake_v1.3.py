'''Coding ka Rule No. 1: If it runs, don't touch it hehe'''

import pygame                                               #imports Pygame module (for functions that need... -_-)
import time                                                 #imports time module   (for functions that need time)
import random                                               #imports random module (for functions that need randomisation)
import os                                                   #imports os module     (for functions that interact with operating system )

pygame.init()                                               #initializing Pygame module

white = (255, 255, 255)                                     #definition of variables (tuples) that hold numbers
yellow = (255, 255, 102)                                    #because we need to have rgb color code for various purposes
black = (0, 0, 0)                                           #now dont ask me the purposes [facepalm emoji]
game_over_color = (252, 64, 64)
red = (213, 50, 80)
green = (0, 255, 0)
blue = (50, 153, 213)

dis_width = 1024                                            #display window width
dis_height = 680                                            #display window height

current_dir = os.path.dirname(__file__)                     #stores the path of current directory in a variable "current_dir"
background_image_path = os.path.join(current_dir, "assets", "images")                                              #image path variable for background image
background = pygame.image.load(os.path.join(background_image_path, "background.png"))                              #declration (loading) of image variable [game background]
background = pygame.transform.scale(background, (dis_width, dis_height))                                           #scale background to fit display
background_game_over_image_path = os.path.join(current_dir, "assets", "images")                                    #image path variable for background game over image
background_game_over = pygame.image.load(os.path.join(background_image_path, "background_game_over.png"))          #declration (loading) of image variable [game over background]
background_game_over = pygame.transform.scale(background_game_over, (dis_width, dis_height))                       #scale background to fit display

snake_block = 15  #snake head size

food_image_path = os.path.join(current_dir, "assets", "images", "food.png")
food_image = pygame.image.load(food_image_path)
food_size = snake_block * 4 # Increase the food size to twice the snake block size
food_image = pygame.transform.scale(food_image, (food_size, food_size))

# Load the head, body, and tail images
snake_head_image_path = os.path.join(current_dir, "assets", "images", "desert_krait_head.png")
snake_head_image = pygame.image.load(snake_head_image_path)
snake_head_image = pygame.transform.scale(snake_head_image, (snake_block, snake_block))

snake_body_image_path = os.path.join(current_dir, "assets", "images", "desert_krait_body.png")
snake_body_image = pygame.image.load(snake_body_image_path)
snake_body_image = pygame.transform.scale(snake_body_image, (snake_block, snake_block))

snake_tail_image_path = os.path.join(current_dir, "assets", "images", "desert_krait_tail.png")
snake_tail_image = pygame.image.load(snake_tail_image_path)
snake_tail_image = pygame.transform.scale(snake_tail_image, (snake_block, snake_block))

dis = pygame.display.set_mode((dis_width, dis_height))      #display window setup
pygame.display.set_caption('Snake Game By Sapphire')        #display window caption

clock = pygame.time.Clock()                                 #game clock

snake_block = 10                        #snake head size
snake_speed = 15                     #snake's movement speed

font_style = pygame.font.SysFont(None, 50)
score_font = pygame.font.SysFont(None, 35)

pygame.draw.rect(dis,red,[100,100,200,200],2)
dis.blit(background, (0, 0))                                # Draw Background   

x1 = round(random.randint(0, dis_width - snake_block) / 10.0) * 10.0        #snake starting location determiner (random)
y1 = round(random.randint(0, dis_height - snake_block) / 10.0) * 10.0
snake_pos = (x1, y1)

def our_snake(snake_block, snake_list):
    for i, x in enumerate(snake_list):
        if i == 0:
            dis.blit(snake_head_image, (x[0], x[1]))  # Draw the head
        elif i == len(snake_list) - 1:
            dis.blit(snake_tail_image, (x[0], x[1]))  # Draw the tail
        else:
            dis.blit(snake_body_image, (x[0], x[1]))  # Draw the body

def message(msg, color):
    game_over = font_style.render(msg, True, color)
    dis.blit(game_over, [dis_width / 4, dis_height / 2])


# #Background music configuration
# pygame.mixer.init()
# pygame.mixer.music.load('Heights at 4.mp3')
# pygame.mixer.music.set_volume(0.10)
# pygame.mixer.music.play(-1)

'''Game Block'''
#all initial values

def game_loop():
    game_over = False
    game_close = False

    x1 = round(random.randint(0, dis_width - snake_block) / 30.0) * 30.0    #snake starting location determiner (random)
    y1 = round(random.randint(0, dis_height - snake_block) / 30.0) * 30.0

    x1_change = 0
    y1_change = 0

    snake_List = []
    Length_of_snake = 1     #initial length of the snake
    snake_up = pygame.K_UP
    snake_down = pygame.K_DOWN
    snake_left = pygame.K_LEFT
    snake_right = pygame.K_RIGHT
    snake_directions = [snake_up, snake_down, snake_left, snake_right]

    foodx = round(random.randrange(0, dis_width - food_size) / 10.0) * 10.0    #food location determiner (random)
    foody = round(random.randrange(0, dis_height - food_size) / 10.0) * 10.0

    while not game_over:        #technically means when game is being played
        dis.blit(background, (0, 0))    # Draw Background
        

        '''Game Controls'''

        while game_close == True:
            #dis.fill(blue)
            dis.blit(background_game_over, (0,0))
            message("You lost! Press Q-Quit or R-Restart", game_over_color)     #message when game is lost

            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:     #'Q' for quit
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_r:     #'R' for restart
                        game_loop()     #as you can see a function call

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            '''Snake head movement directions'''        """Controls Configuration Sorting & Controls Conflict Solving done by Roushna"""
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_LEFT, pygame.K_a] and x1_change == 0:
                    x1_change = -snake_block
                    y1_change = 0
                elif event.key in [pygame.K_RIGHT, pygame.K_d] and x1_change == 0:
                    x1_change = snake_block
                    y1_change = 0
                elif event.key in [pygame.K_UP, pygame.K_w] and y1_change == 0:
                    y1_change = -snake_block
                    x1_change = 0
                elif event.key in [pygame.K_DOWN, pygame.K_s] and y1_change == 0:
                    y1_change = snake_block
                    x1_change = 0

        if x1 >= dis_width-1 or x1 < 0 or y1 >= dis_height-1 or y1 < 0:     #if snake head touches either boundaries, game closes
            game_close = True
        x1 += x1_change     
        y1 += y1_change
        dis.blit(background, (0, 0))    # Draw Background
        dis.blit(food_image, (foodx, foody))          # Display food image
        snake_Head = []
        snake_Head.append(x1)
        snake_Head.append(y1)
        snake_List.append(snake_Head)
        if len(snake_List) > Length_of_snake:
            del snake_List[0]

        for x in snake_List[:-1]:
            if x == snake_Head:     #if snake bites itself, game lost
                game_close = True

        our_snake(snake_block, snake_List)

        pygame.display.update()

        # Check if the snake's head collides with the food
        if x1 >= foodx and x1 < foodx + food_size and y1 >= foody and y1 < foody + food_size:
            foodx = round(random.randrange(0, dis_width - food_size) / 10.0) * 10.0
            foody = round(random.randrange(0, dis_height - food_size) / 10.0) * 10.0
            Length_of_snake += 1            #snake's length increment, when upon eating food

        clock.tick(snake_speed)

    pygame.quit()       #click quit (cross) button to exit window
    quit()


game_loop()